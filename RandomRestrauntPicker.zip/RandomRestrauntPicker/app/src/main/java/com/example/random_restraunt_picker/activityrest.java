package com.example.random_restraunt_picker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static okhttp3.Protocol.HTTP_2;


public class activityrest extends AppCompatActivity {

    TextView restaurantName;
    ImageView restaurantImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activityrest);
        getYelpData();
    }

    private void getYelpData()
    {
        OkHttpClient client = new OkHttpClient();



        //String apiKey = "0-WoLcstf08d_rXLPO1zSIe-VnBlDwLt0pQzhdu3eFqSBQNQoDHqTrrMcqfB--gRsENuLIAunA1Dsahd_6drFDEogDkyMo_ifi5JM3_PDAkJL_0kLIsCWKoxM7iWW3Yx";

        Request request = new Request.Builder()
                .url("https://api.yelp.com/v3/businesses/search?categories=Restaurants&location=Macomb,IL")
                .addHeader("Authorization", "Bearer 0-WoLcstf08d_rXLPO1zSIe-VnBlDwLt0pQzhdu3eFqSBQNQoDHqTrrMcqfB--gRsENuLIAunA1Dsahd_6drFDEogDkyMo_ifi5JM3_PDAkJL_0kLIsCWKoxM7iWW3Yx")
                .get()
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e)
            {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException
            {
                if (response.isSuccessful())
                {
                    String myResponse = response.body().string();

                    Log.d("JSON", myResponse);
                }

            }
        });
    }
}
